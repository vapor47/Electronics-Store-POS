﻿using Microsoft.EntityFrameworkCore;
using POS_Data.Tables;

using System;

namespace POS_Data
{
    public class POS_Context : DbContext
    {
        public POS_Context(DbContextOptions options) : base(options)
        {
            
        }

        public DbSet<User> User { get; set; }
    }
}
